# UI_zadania
Vypracované zadania z predmetu Umelá Inteligencia 2024 - Z1B, Z2B, Z3B
